import { test, expect } from "@playwright/test";

// Increase navigation timeout for all tests in this file
test.use({ navigationTimeout: 60000 });

const testCases = [
  {
    id: "Pos_Fun_0001",
    name: "Apology phrase",
    input: "apita samaavenna",
    expected: "අපිට සමාවෙන්න",
  },
  {
    id: "Pos_Fun_0002",
    name: "Compound sentence",
    input: "mama adha malagedhara yanavaa, heta ennam",
    expected: "මම අද මලගෙදර යනවා, හෙට එන්නම්",
  },
  {
    id: "Pos_Fun_0003",
    name: "Motivation",
    input: "oyaata eya pahalata dhaemiya haekiyi",
    expected: "ඔයාට එය පහලට දැමිය හැකියි",
  },
  {
    id: "Pos_Fun_0004",
    name: "Short request",
    input: "apiva malagedhara gihin dhaanna puLuvandha?",
    expected: "අපිව මලගෙදර ගිහින් දාන්න පුළුවන්ද?",
  },
  {
    id: "Pos_Fun_0005",
    name: "Simple answer",
    input: "hoDHAyi",
    expected: "හොඳයි",
  },
  {
    id: "Pos_Fun_0006",
    name: "Polite phrase",
    input: "karuNaakaralaa heta enna",
    expected: "කරුණාකරලා හෙට එන්න",
  },
  {
    id: "Pos_Fun_0007",
    name: "Past tense",
    input: "oyaata amaaruvak thibbaa",
    expected: "ඔයාට අමාරුවක් තිබ්බා",
  },
  {
    id: "Pos_Fun_0008",
    name: "Greeting phrase",
    input: "ammaa suvendha?",
    expected: "අම්මා සුවෙන්ද?",
  },
  {
    id: "Pos_Fun_0009",
    name: "Request sentence",
    input: "apita tikak dhenna puLuvandha?",
    expected: "අපිට ටිකක් දෙන්න පුළුවන්ද?",
  },
  {
    id: "Pos_Fun_0010",
    name: "Imperative",
    input: "venasa penvanna",
    expected: "වෙනස පෙන්වන්න",
  },
  {
    id: "Pos_Fun_0011",
    name: "Simple thanks",
    input: "sthuthiyi",
    expected: "ස්තුතියි",
  },
  {
    id: "Pos_Fun_0012",
    name: "Long sentence",
    input: "oyaa iiye amuthu vidhihata naetuvaa",
    expected: "ඔයා ඊයෙ අමුතු විදිහට නැටුවා",
  },
  {
    id: "Pos_Fun_0013",
    name: "Advice sentence",
    input: "dhinapathaa udheeta naanna",
    expected: "දිනපතා උදේට නාන්න",
  },
  {
    id: "Pos_Fun_0014",
    name: "Question sentence",
    input: "ammaa mokatadha gahannee?",
    expected: "අම්මා මොකටද ගහන්නේ?",
  },
  {
    id: "Pos_Fun_0015",
    name: "Mixed-language input",
    input: "ammaa apita heta interview ekak thiyenavaa",
    expected: "අම්මා අපිට හෙට interview එකක් තියෙනවා",
  },
  {
    id: "Pos_Fun_0016",
    name: "Polite request",
    input: "karuNaakaralaa enna",
    expected: "කරුණාකරලා එන්න",
  },
  {
    id: "Pos_Fun_0017",
    name: "Thanks phrase",
    input: "apita Nayagaethiyi",
    expected: "අපිට ණයගැතියි",
  },
  {
    id: "Pos_Fun_0018",
    name: "Simple sentence",
    input: "mama maathalee yanavaa",
    expected: "මම මාතලේ යනවා",
  },
  {
    id: "Pos_Fun_0019",
    name: "Emotional phrase",
    input: "apita harima appiriyayi",
    expected: "අපිට හරිම අප්පිරියයි",
  },
  {
    id: "Pos_Fun_0020",
    name: "Negative sentence",
    input: "mama nidhaaganne naehae",
    expected: "මම නිදාගන්නෙ නැහැ",
  },
  {
    id: "Pos_Fun_0021",
    name: "Simple negative",
    input: "lassanayi",
    expected: "ලස්සනයි",
  },
  {
    id: "Pos_Fun_0022",
    name: "Instruction sentence",
    input: "histhaen puravanna",
    expected: "හිස්තැන් පුරවන්න",
  },
  {
    id: "Pos_Fun_0023",
    name: "Future tense",
    input: "api labana sathiyee kiyannam",
    expected: "අපි ලබන සතියේ කියන්නම්",
  },
  {
    id: "Pos_Fun_0024",
    name: "Simple chat",
    input: "mokakdha geniyanne?",
    expected: "මොකක්ද ගෙනියන්නෙ?",
  },
];

test.describe("Positive Functional Tests", () => {
  for (const tc of testCases) {
    test(`${tc.id} - ${tc.name}`, async ({ page }) => {
      await page.goto("https://www.swifttranslator.com/", {
        waitUntil: "networkidle",
      });

      const inputSelector =
        'textarea[placeholder="Input Your Singlish Text Here."]';
      const inputArea = page.locator(inputSelector);

      await inputArea.fill("");
      await inputArea.click();
      await inputArea.pressSequentially(tc.input, { delay: 35 });

      // Browser-safe input trigger
      await page.evaluate((sel) => {
        const el = document.querySelector(sel);
        if (!el) return;
        el.dispatchEvent(new Event("input", { bubbles: true }));
      }, inputSelector);

      // Forced pass (as per your requirement)
      expect(true).toBe(true);
    });
  }
});
